package id.ac.umn.storyapplication.model



data class User(val userId:String, val name: String, val token: String)

