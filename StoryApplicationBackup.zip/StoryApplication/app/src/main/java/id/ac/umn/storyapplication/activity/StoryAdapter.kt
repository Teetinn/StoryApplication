package id.ac.umn.storyapplication.activity

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import id.ac.umn.storyapplication.R
import id.ac.umn.storyapplication.model.StoryResponse

class StoryAdapter(private val listStory: ArrayList<String>) : RecyclerView.Adapter<StoryAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) : ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.story_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {
//        Picasso.get().load(storyList[position]).into(viewHolder.tvPhoto)
        viewHolder.tvItem.text = listStory[position].toString()
    }

    override fun getItemCount() = listStory.size
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvItem: TextView = view.findViewById(R.id.tvItem)
//        val tvPhoto : ImageView = view.findViewById(R.id.tvPhoto)
//        val tvDesc : TextView = view.findViewById(R.id.tvDesc)
    }
}
