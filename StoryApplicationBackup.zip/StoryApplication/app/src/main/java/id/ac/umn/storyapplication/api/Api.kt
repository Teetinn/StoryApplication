package id.ac.umn.storyapplication.api

import id.ac.umn.storyapplication.model.DefaultResponse
import id.ac.umn.storyapplication.model.LoginResponse
import id.ac.umn.storyapplication.model.StoryResponse
import retrofit2.Call
import retrofit2.http.*

interface Api {

    @FormUrlEncoded
    @POST("register")
    fun register(
        @Field("name") name:String,
        @Field("email") email:String,
        @Field("password") password:String
    ):Call<DefaultResponse>

    @FormUrlEncoded
    @POST("login")
    fun userLogin(
        @Field("email") email: String,
        @Field("password") password: String
    ):Call<LoginResponse>


    @GET("stories")
    fun getStory(@Header("Authorization") token:String): Call<StoryResponse>
}