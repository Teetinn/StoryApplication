package id.ac.umn.storyapplication.model

data class DefaultResponse (val error: Boolean, val message: String)