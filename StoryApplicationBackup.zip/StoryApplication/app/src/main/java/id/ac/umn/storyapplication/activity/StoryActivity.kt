package id.ac.umn.storyapplication.activity

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import id.ac.umn.storyapplication.api.RetrofitClient
import id.ac.umn.storyapplication.databinding.ActivityStoryBinding
import id.ac.umn.storyapplication.model.StoryResponse
import id.ac.umn.storyapplication.storage.SharedPrefManager
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class StoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityStoryBinding



//    private lateinit var listStory : List<StoryResponse.Story>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonLogout.setOnClickListener{

            SharedPrefManager.getInstance(this).clear()

            val intent = Intent(applicationContext, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

            startActivity(intent)
        }
    }



        private fun setStoryList(listCerita: List<StoryResponse.Story>) {


            val listStory = ArrayList<String>()
            for (cerita in listCerita) {
                listStory.add(
                    """{$cerita.name}
                        
                    """.trimIndent()
                )
            }

            val storyAdapter = StoryAdapter(listStory)
            binding.rvStory.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL ,false)
            binding.rvStory.adapter = storyAdapter
        }




    override fun onResume(){
        super.onResume()



        val loginTokenSpm : String =  SharedPrefManager.getInstance(this).loginResult.token

        RetrofitClient.instance.getStory(token = "Bearer $loginTokenSpm").enqueue(object : Callback<StoryResponse> {
            override fun onResponse(
                call: Call<StoryResponse>,
                response: Response<StoryResponse>
            ) {
                val responseBody = response.body()
                if (responseBody != null) {
                    Log.e(TAG, "onSuccess: ${response.message()}")
                    setStoryList(responseBody.listStory)
                }else{
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<StoryResponse>, t: Throwable) {
                Log.e(TAG, "onFailure2: ${t.message}")
            }
        })
    }



    override fun onStart() {
        super.onStart()

        if(!SharedPrefManager.getInstance(this).isLoggedIn) {
            val intent = Intent(applicationContext, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

            startActivity(intent)
        }
    }
}
