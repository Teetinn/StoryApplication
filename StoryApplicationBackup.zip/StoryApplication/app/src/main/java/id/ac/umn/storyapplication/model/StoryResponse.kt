package id.ac.umn.storyapplication.model


data class StoryResponse(
    val error: Boolean,
    val message: String,
    val listStory: ArrayList<Story>
    ) {
    data class Story(
        val id: String,
        val name: String,
        val description: String,
        val photoUrl: String
        )
}


